"""Send a reply from the proxy without sending any data to the remote server."""
from mitmproxy import http
import random

def request(flow: http.HTTPFlow) -> None:
    if flow.request.pretty_url.__contains__("management.azure.com"):
        list1 = [0,1]
        #x = random.choice(list1)
        x = 0
        if x == 0:
            flow.response = http.Response.make(
            500,  # (optional) status code
            #b"Hello World",  # (optional) content
            #{"Content-Type": "text/html"},  # (optional) headers
        )
