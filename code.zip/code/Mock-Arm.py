"""Send a reply from the proxy without sending any data to the remote server."""
from mitmproxy import http
import random

def request(flow: http.HTTPFlow) -> None:
    if flow.request.pretty_url.__contains__("management.azure.com"):
        list1 = [0,1]
        #x = random.choice(list1)
        x = 0
        if x == 0:
            flow.response = http.Response.make(
            500,  # (optional) status code
            #b"Hello World",  # (optional) content
            #{"Content-Type": "text/html"},  # (optional) headers
        )


def response(flow: http.HTTPFlow) -> None:
    # Check if the response is an API response
    print('API response received for URL:' + flow.request.url)
    if 'api' in flow.request.url:
        # Get the response content
        response_content = flow.response.content

        # Analyze the response content
        if 'error' in response_content:
            # If the response indicates an error, block traffic
            print('API response contained an error, blocking traffic')
            flow.response.status_code = 403
            flow.response.content = 'Access Denied'
            # TODO: Add code here to block traffic using other tools if necessary

        # If the response is successful, continue with normal processing
        else:
            print('API response was successful')

def save_to_file(self):
    # Serialize the captured data to a file
    with open('captured_data.json', 'a') as file:
        json.dump(self.requests, file, indent=4)