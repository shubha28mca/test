import mitmproxy
import json
import sys
import os

# Get the major and minor version numbers
major_version = sys.version_info.major
minor_version = sys.version_info.minor

# Print the version
print("Python version:", f"{major_version}.{minor_version}")

# Get the path to the Python executable
python_executable = sys.executable

# Print the path
print("Path to Python executable:", python_executable)

# Get the current working directory
current_dir = os.getcwd()
#current_dir = os.path.join(current_dir + "\\libs\\azure-cosmos-4.5.0\\azure-cosmos-4.5.0")
print(current_dir)
# Add the current directory to sys.path
sys.path.append(os.path.join(current_dir + "\\libs\\azure-cosmos-4.5.0\\azure-cosmos-4.5.0"))
sys.path.append(os.path.join(current_dir + "\\libs\\azure-core-1.29.1\\azure-core-1.29.1"))
sys.path.append(os.path.join(current_dir + "\\libs\\certifi-2023.7.22"))
sys.path.append(os.path.join(current_dir + "\\libs\\charset-normalizer-3.2.0"))
sys.path.append(os.path.join(current_dir + "\\libs\\idna-3.4"))
sys.path.append(os.path.join(current_dir + "\\libs\\requests-2.31.0"))
sys.path.append(os.path.join(current_dir + "\\libs\\six-1.16.0"))
sys.path.append(os.path.join(current_dir + "\\libs\\typing_extensions-4.7.1\\src"))
sys.path.append(os.path.join(current_dir + "\\libs\\urllib3-2.0.4"))

print(sys.path)

from azure.cosmos import CosmosClient, PartitionKey
import uuid

#Connect to a specific database and container
try:
    endpoint = "https://shrauta-chaos-cosmos-db.documents.azure.com:443/"
    key = "oGVXgOpho5p6sPPzS4b7gJgmGwy0sUE3h47UlCU3CWS6wBPzrZyj7tZjftPjgNjV5E738BXbCPp4ACDbhZP8pA=="
    client = CosmosClient(endpoint, key)

    # Create or access the database
    database_name = "ChaosDB"
    database = client.create_database_if_not_exists(id=database_name)

    # Create or access the container
    container_name = "communication"
    container = database.create_container_if_not_exists(
        id=container_name,
        partition_key=PartitionKey(path="/partitionKey"),
        offer_throughput=400
    )

    # Insert the data into the container
    container.upsert_item(body=data[url])
    data[url] = {}
except Exception as e:
    print("An error occurred while connecting to Cosmos DB:")
    print(e)