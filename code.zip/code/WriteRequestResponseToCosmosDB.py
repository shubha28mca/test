import mitmproxy
import json
import sys
import os

# Get the major and minor version numbers
major_version = sys.version_info.major
minor_version = sys.version_info.minor

# Print the version
print("Python version:", f"{major_version}.{minor_version}")

# Get the path to the Python executable
python_executable = sys.executable

# Print the path
print("Path to Python executable:", python_executable)

# Get the current working directory
current_dir = os.getcwd()
#current_dir = os.path.join(current_dir + "\\libs\\azure-cosmos-4.5.0\\azure-cosmos-4.5.0")
print(current_dir)
# Add the current directory to sys.path
sys.path.append(os.path.join(current_dir + "\\libs\\azure-cosmos-4.5.0\\azure-cosmos-4.5.0"))
sys.path.append(os.path.join(current_dir + "\\libs\\azure-core-1.29.1\\azure-core-1.29.1"))
sys.path.append(os.path.join(current_dir + "\\libs\\certifi-2023.7.22"))
sys.path.append(os.path.join(current_dir + "\\libs\\charset-normalizer-3.2.0"))
sys.path.append(os.path.join(current_dir + "\\libs\\idna-3.4"))
sys.path.append(os.path.join(current_dir + "\\libs\\requests-2.31.0"))
sys.path.append(os.path.join(current_dir + "\\libs\\six-1.16.0"))
sys.path.append(os.path.join(current_dir + "\\libs\\typing_extensions-4.7.1\\src"))
sys.path.append(os.path.join(current_dir + "\\libs\\urllib3-2.0.4"))

print(sys.path)

from azure.cosmos import CosmosClient, PartitionKey
import uuid


data = {}

def response(flow: mitmproxy.flow.Flow):
    # Capture and print response details
    url = flow.request.url
    new_id = str(uuid.uuid4())
    data[url] = {
        "id": new_id,
        "url": url,
        "request": {
            "method": flow.request.method,
            "headers": dict(flow.request.headers),
            "body": flow.request.text,
        }
    }
    print("--- Response ---")
    print("Status Code:", flow.response.status_code)
    print("Headers:", flow.response.headers)
    print("Body:", flow.response.text)
    print()
    if url in data:
        data[url]["response"] = {
            "status_code": flow.response.status_code,
            "headers": dict(flow.response.headers),
            "body": flow.response.text,
        }
        # Write updated array back to the file
        with open("data.json", "w") as json_file:
            json.dump(data[url], json_file, indent=4)



