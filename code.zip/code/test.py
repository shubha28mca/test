import mitmproxy
import json

data = {}
# def request(flow: mitmproxy.flow.Flow):
#     # Capture and print request details
#     print("--- Request ---")
#     print("URL:", flow.request.url)
#     print("Method:", flow.request.method)
#     print("Headers:", flow.request.headers)
#     print("Body:", flow.request.text)
#     print()
#     url = flow.request.url
#     data[url] = {
#         "request": {
#             "method": flow.request.method,
#             "headers": dict(flow.request.headers),
#             "body": flow.request.text,
#         }
#     }

def response(flow: mitmproxy.flow.Flow):
    # Capture and print response details
    url = flow.request.url
    data[url] = {
        "url": url,
        "request": {
            "method": flow.request.method,
            "headers": dict(flow.request.headers),
            "body": flow.request.text,
        }
    }
    print("--- Response ---")
    print("Status Code:", flow.response.status_code)
    print("Headers:", flow.response.headers)
    print("Body:", flow.response.text)
    print()
    if url in data:
        data[url]["response"] = {
            "status_code": flow.response.status_code,
            "headers": dict(flow.response.headers),
            "body": flow.response.text,
        }
        with open('captured_data.json', 'a') as file:
            json.dump(data[url], file, indent=4)
            data[url] = {}



